var express = require('express');
var router = express.Router();
var connection = require('../db/sql.js');

// 获取用户的通讯录，并按置顶状态排序
router.get('/getAddressBook', async function(req, res, next) {
    let sql = 'SELECT * FROM xzx ORDER BY is_top DESC, id ASC';
    let contacts = await connection.sqlConnection(sql, []);
    res.json(contacts);
});

// 删除用户的通讯录
router.post('/deleteAddressBook', async function(req, res, next) {
    let id = req.body.id;
    console.log(id);
    let sql = 'DELETE FROM xzx WHERE id = ?';
    let addressBook = await connection.sqlConnection(sql, [id]);
    res.send(addressBook);
});

// 增加或更新用户通讯录信息
router.post('/addAddressBook', async function(req, res, next) {
    let name = req.body.name;
    let email = req.body.email;
    let phone = req.body.phone;

    const getAccountId = async (name) => {
        const sql = 'SELECT * FROM xzx WHERE name = ?';
        let res = await connection.sqlConnection(sql, [name]);
        return res[0] ? res[0].id : false;
    };

    let id = await getAccountId(name);
    if (id == false) {
        let sql = 'INSERT IGNORE INTO xzx (name, email, phone) VALUES (?, ?, ?)';
        let report = await connection.sqlConnection(sql, [name, email, phone]);
        res.send(report);
    } else {
        let sql = 'UPDATE xzx SET phone = ?, name = ?, email = ? WHERE id = ?';
        let report = await connection.sqlConnection(sql, [phone, name, email, id]);
        res.send(report);
    }
});

// 设置用户置顶状态
router.post('/toggleTopStatus', async function(req, res, next) {
    let id = req.body.id;
    let sql = 'UPDATE xzx SET is_top = NOT is_top WHERE id = ?';
    let result = await connection.sqlConnection(sql, [id]);
    res.send(result);
});

module.exports = router;